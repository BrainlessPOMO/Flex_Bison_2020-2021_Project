Ονοματεπώνυμα , ΑΜ , EMAILS:
___________________________________
=> Χατζηγαβριήλ Ανδρέας , 1056645 ,    st1056645@ceid.upatras.gr
   antreashadh@gmail.com

=> Παλαμάς Ανδρέας , 1049789 , 
   st1049789@ceid.upatras.gr
   andreaspalamas@hotmail.com
 
=> Γεωργίου Γεώργιος , 1049797 ,
   st1048989@ceid.upatras.gr
   giorgos-3197@hotmail.com
					
=> Κυριάκου Χρήστος , 1050002 , 
   ckyriakou@ceid.upatras.gr
			     